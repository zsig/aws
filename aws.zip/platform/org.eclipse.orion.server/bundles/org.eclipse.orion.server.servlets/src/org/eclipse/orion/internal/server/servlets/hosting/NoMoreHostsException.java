/*******************************************************************************
 * Copyright (c) 2011 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.orion.internal.server.servlets.hosting;

/**
 * Thrown when an attempt is made to host a site configuration, but all domains and IPs
 * available for use as virtual host names have already been allocated.
 */
public class NoMoreHostsException extends SiteHostingException {
	private static final long serialVersionUID = 1L;

	public NoMoreHostsException(String msg) {
		super(msg);
	}

	public NoMoreHostsException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
