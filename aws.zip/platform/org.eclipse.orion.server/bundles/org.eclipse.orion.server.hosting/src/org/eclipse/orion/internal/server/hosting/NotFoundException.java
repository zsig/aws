package org.eclipse.orion.internal.server.hosting;

import javax.servlet.ServletException;

public class NotFoundException extends ServletException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
